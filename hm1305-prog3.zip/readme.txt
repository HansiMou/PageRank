OS

To compile:
javac -cp jtidy-r938.jar *.java

To run:
example:

java -cp jtidy-r938.jar:. PageRank -docs example -f 0.7